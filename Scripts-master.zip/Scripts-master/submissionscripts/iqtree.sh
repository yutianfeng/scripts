#!/bin/bash
#SBATCH --job-name=reroot
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 6
#SBATCH --partition=amd
#SBATCH --mail-type=END
#SBATCH --mem=50G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o reroot_%j.out
#SBATCH -e reroot_%j.err


module load  iqtree/1.5.5
iqtree-omp -s cdsall7.align -nt AUTO -bb 1000 -st AA 
