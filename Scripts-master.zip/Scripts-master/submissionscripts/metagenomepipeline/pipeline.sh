

###################### search an AA metagenome with all intein pssms ###################


######### *.out = sequence used to make pssm
######### *.chk= pssm
######### *.psiout= hits from pssm

for filn in `cat pssm.list`;do blastpgp -i $filn.out -R $filn.chk -d **** -j 1 -o $filn.psiout -m 8;
done
#use each pssm to blast a metagenome (-d) this command will only work for aa metagenomes
#this must be done in a directory containing all the pssms, an infile for each pssm, and the
#metagenome that the user intends to search which has been previously formated into a db,
#and a list of the names of each pssm in a file called pssm.list

###########extract all the hits from a metagenome using all PSSMs #######################
 ################ remove redundant sequences  hit in multiple PSSMs #####################


cat *.psiout |cut -f 2 >all.hits
#list all of the hits from a psiblast using all intein PSSMs

sort all.hits >sort.hits
#sort all of the hits alphabetically by contig name from metagenome file

uniq sort.hits >mg_name.hits
#extract only unique hits mg_name.hits is a list of contigs which were found by PSSMs


for filn in `cat mg_name.hits`; do grep -A 1 $filn mg.fas> $filn.seqfile;done
#makes a list of all of the contigs and searches for the corresponding fasta sequence in the metagenome .fas file

ls *.seqfile|cut -d "." -f 1 >seqfile.list
#for filn in `cat seqfile.list`; do blastall -p blastp -i $filn.seqfile -o $filn.blastout -m 8 -d first_db;done

for filn in `cat yellow.hits`; do blastx -query $filn.seqfile -db intein.db -outfmt 6 -out $filn.blast ;done
#new blast
#blast each contig against a db of inteins, hnt, bil, he, mid domains

#for filn in `cat seqfile.list`;do grep -m 1 "_" $filn.blastout >$filn.tsbh;done
for f in `cat yellow.hits`; do head -1 $f.blast > $f.tsbh; done
#works for all
#extract tsbh for each contig, identifies hit as being BIL, HNT, HE, mid, or intein

cat *.tsbh > all.tsbh
#make one file of all the tsbh for all contigs 

grep ":HE" all.tsbh > mg.he
#extract contigs idetified as HEs and put them in file 
grep ":mid" all.tsbh >mg.mid
#extract all contigs identified as mid domains
grep "BIL:" all.tsbh > mg.bil
#extract all contigs identified as BIL domains
grep "|*:" all.tsbh > mg.HNT
#extract all contigs identified as HNT domains
grep -v ":HE" all.tsbh | grep -v ":mid" | grep -v "BIL:" |grep -v "|*:" > mg.intein
#extract all contigs identified as inteins

cut -f 12 mg.intein > mg.intein.bits
#makes a file of only the bit scores for each intein hit
paste mg.intein.bits mg.intein > mg.bit.inteins
#makes a file where the bit score is the first column so it can be sorted by bit score
sort mg.bit.inteins >mg.int.sorted
#sorts the file based on the bit score

# at this point the user needs to determine how many of the hits should be extracts I have 
#determined that bits of 100 or more are actually inteins anything under that cannot be reliably aligned
# to the identified intein hit, once the user has determined how many of the hits are above 100
#use tail to grab _ hits from the bottom of the list for instance if the last 20 hits are 
#above 100: tail -n 20 mg.int.sorted >mg.int.significant

################ once hits are extracted they need to be blasted against the #############
################ nr db to identify the extein the intein may be inserted into ############

cut -f 1 mg.int.significant > contigs.list
#makes a list of the contigs in the list which have hits over 100
for filn in `cat contigs.list`; do blastall -p blastp -i $filn.seqfile -d nr -m 8 -o $filn.outfile; done
#blasts nr db with significant contigs

for filn in `cat contigs.list`; do grep -m 1 "gi" $filn.outfile > $filn.nr.tsbh;done
#extracts tsbh from nr db

for filn in `cat contigs.list`; do cut -f 2 $filn.nr.tsbh >$filn.nr.gi;done
#extracts gi # from the tsbh of each contig

for filn in `cat contig.list`; do fastacmd -i $filn.nr.gi -o $filn.nr.hit ;done 
#extract sequences from nr which correspond to the contigs used to search nr 