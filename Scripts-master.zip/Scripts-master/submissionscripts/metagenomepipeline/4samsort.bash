#!/bin/bash
#SBATCH --job-name=samsort
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 4
#SBATCH --partition=amd
#SBATCH --mail-type=END
#SBATCH --mem=250G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o samsort_%j.out
#SBATCH -e samsort_%j.err


module load  samtools/1.7
samtools sort bothmap.bam -o bothsort08.bam
samtools sort exmap.bam -o exsort08.bam