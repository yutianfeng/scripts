#!/bin/bash
#SBATCH --job-name=mapping
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 10
#SBATCH --partition=amd
#SBATCH --mail-type=END
#SBATCH --mem=30G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o mapping_%j.out
#SBATCH -e mapping_%j.err


module load  bowtie2/2.3.3.1
bowtie2 -x extein30 -U /home/CAM/yfeng/metagenomes/deeplake/DL24m30.fastq -S ex30map.sam -p 10 
bowtie2 -x both30 -U /home/CAM/yfeng/metagenomes/deeplake/DL24m30.fastq -S comb30map.sam -p 10 