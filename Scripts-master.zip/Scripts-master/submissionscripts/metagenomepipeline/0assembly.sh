#!/bin/bash
#SBATCH --job-name=assing
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 16
#SBATCH --partition=himem4
#SBATCH --mail-type=END
#SBATCH --mem=500G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o assing_%j.out
#SBATCH -e assing_%j.err



module load SPAdes/3.11.1

spades.py --pe1-1 /UCHC/LABS/Gogarten/metagenomes/meyghan/ERR1739732_1.trim.fq --pe1-2 /UCHC/LABS/Gogarten/metagenomes/meyghan/ERR1739732_2.trim.fq -o assembly2
spades.py --pe1-1 /UCHC/LABS/Gogarten/metagenomes/meyghan/ERR1739731_1.trim.fq --pe1-2 /UCHC/LABS/Gogarten/metagenomes/meyghan/ERR1739731_2.trim.fq -o assembly3