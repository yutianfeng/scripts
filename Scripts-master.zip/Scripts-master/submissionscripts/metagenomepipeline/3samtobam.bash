#!/bin/bash
#SBATCH --job-name=samsort
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 1
#SBATCH --partition=amd
#SBATCH --mail-type=END
#SBATCH --mem=20G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o samsort_%j.out
#SBATCH -e samsort_%j.err


module load  samtools/1.7
samtools view -b -F 4 comb30map.sam > both30map.bam
samtools view -b -F 4 ex30map.sam > ex30map.bam