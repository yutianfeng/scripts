#!/bin/bash
#SBATCH --job-name=trimm
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 4
#SBATCH --partition=amd
#SBATCH --mail-type=END
#SBATCH --mem=250G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o trim_%j.out
#SBATCH -e trim_%j.err


module load sickle/1.33
sickle se -f DL24m30.fastq -t sanger -o tDL24m30.fq
sickle se -f DL24m08.fastq -t sanger -o tDL24m08.fq
