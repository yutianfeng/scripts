#!/bin/bash
#SBATCH --job-name=nrblast
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 9
#SBATCH --partition=amd
#SBATCH --mail-type=END
#SBATCH --mem=40G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o nrblast_%j.out
#SBATCH -e nrblast_%j.err



module load blast/2.7.1
for filn in *.seqfile; do blastx -query $filn -db /home/CAM/yfeng/inteindb/intein.db -outfmt "6 qaccver qstart qstop qseq" -max_target_seqs 1 >> seqs.tsbh ;done