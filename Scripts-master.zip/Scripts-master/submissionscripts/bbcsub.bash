#!/bin/bash
#$ -N ass
#$ -M yutian.feng@uconn.edu
#$ -q all.q
#$ -m ea
#$ -S /bin/bash
#$ -cwd
#$ -pe smp 16
#$ -o ass_$JOB_ID.out
#$ -e ass_$JOB_ID.err

cd /home/yuf17006/metagenomes
module load  SPAdes/3.10.0
spades.py --meta --only-asembler --pe<1>-1 ERR1739731_1.fastq --pe<1>-2 ERR1739731_2.fastq  -o test1


