#!/usr/bin/perl -w

use strict;
 

my $infasta=$ARGV[0];
 
open FH1 , "$infasta" or die "$!";



my @sequence ="";
my $first = "";
my $second ="";
my $begin="";
my $end="";
my $front = "";
my $back = "";
my $final = "";
while(<FH1>){
	chomp;
	@sequence = split /\t/, $_;
	$first = $sequence[6];
	$second = $sequence[7];
	if ($first > $second) {
		 $begin = $second;
 		 $end = $first;
	}
	else{
		$begin = $first;
		$end = $second;
	}
	my $seqname = $sequence[0];
	open FH2, "$seqname".".seqfile2";
	my $worthless ="";
	my $cds= "";
	while(<FH2>){
		chomp;
		if(/^\>(.*)/){
			$worthless = $worthless . $_;
		}
		else{
			$cds = $cds . $_;
		}
	}
	
	my @readin = split //, $cds;
	my $i =0;
	
	while ($i < $begin){
		$front = $front . $readin[$i];
		$i += 1;
	}
	
	while ($end < $#readin){
		$back = $back . $readin[$end];
		$end += 1;
	}
	$final = $front . $back;
	
	print ">".$sequence[0].".ext\n".$final."\n";
	@sequence ="";
	$front ="";
	$final ="";
	$back ="";
	$first = "";
	$second ="";
	$begin="";
	$end="";
}
