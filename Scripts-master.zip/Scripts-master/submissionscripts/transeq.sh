#!/bin/bash
#SBATCH --job-name=trans
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 10
#SBATCH --partition=amd
#SBATCH --mail-type=END
#SBATCH --mem=50G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o trans_%j.out
#SBATCH -e trans_%j.err


cd /home/CAM/yfeng/metagenomes/test1
module load emboss/6.6.0
transeq -sequence contigs.fasta -outseq transcont.fasta -frame 6 -clean