#!/bin/bash
#SBATCH --job-name=prokka
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 16
#SBATCH --partition=amd
#SBATCH --mail-type=END
#SBATCH --mem=50G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o prokka_%j.out
#SBATCH -e prokka_%j.err


cd /home/CAM/yfeng/metagenomes/worked/test2ass
module load prokka/1.11 
prokka --outdir annotated --prefix annocontigs contigs.fasta