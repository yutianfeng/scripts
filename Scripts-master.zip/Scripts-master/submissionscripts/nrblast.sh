#!/bin/bash
#SBATCH --job-name=nrblast
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 20
#SBATCH --partition=himem4
#SBATCH --mail-type=END
#SBATCH --mem=250G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o nrblast_%j.out
#SBATCH -e nrblast_%j.err



module load blast/2.7.1
for filn in *.txt; do blastx -query $filn -db /isg/shared/databases/blast/nr -outfmt "6 qaccver sgi sallgi sseqid qseq" -out exteinbackground.tab -max_target_seqs 1 -evalue 1e-10 -num_threads 20; done
