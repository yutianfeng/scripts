#!/bin/bash
#SBATCH --job-name=psi
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 4
#SBATCH --partition=amd
#SBATCH --mail-type=END
#SBATCH --mem=100G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o psi_%j.out
#SBATCH -e psi_%j.err



module load blast/2.7.1
for b in *.fa; do psiblast -query "$b" -db /isg/shared/databases/blast/nr -out ${b%.fa}.blast -outfmt 6 -num_iterations 5 -out_pssm ${b%.fa}.pssm -save_pssm_after_last_round; done 