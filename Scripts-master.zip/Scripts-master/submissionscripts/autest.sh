#!/bin/bash
#SBATCH --job-name=tblastn
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 6
#SBATCH --partition=amd
#SBATCH --mail-type=END
#SBATCH --mem=250G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o tblastn_%j.out
#SBATCH -e tblastn_%j.err



module load iqtree/1.5.5
iqtree-omp -s inteinaa.align -st AA -m LG+F+I+G4 -n 0 -z exteinaa.ufb -zb 1000 -au -nt AUTO
iqtree-omp -s exteinaa.align -st AA -m LG+F+R5 -n 0 -z inteinaa.ufb -zb 1000 -au -nt AUTO