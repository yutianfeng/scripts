#!/bin/bash
#SBATCH --job-name=raxml
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 16
#SBATCH --partition=amd
#SBATCH --mail-type=END
#SBATCH --mem=20G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o racks_%j.out
#SBATCH -e racks_%j.err



module load RAxML/8.2.11
raxmlHPC ­f i ­t extein.te ­z inteinaa.align.ufboot ­m GTRCAT ­n T4
 