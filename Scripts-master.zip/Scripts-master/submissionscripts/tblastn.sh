#!/bin/bash
#SBATCH --job-name=tblastn
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 1
#SBATCH --partition=amd
#SBATCH --mail-type=END
#SBATCH --mem=50G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o tblastn_%j.out
#SBATCH -e tblastn_%j.err



module load blast/2.7.1
for b in *.pssm; do tblastn -in_pssm "$b" -db contigs.fasta -out "$b".search -outfmt 6 -evalue 1e-10; done