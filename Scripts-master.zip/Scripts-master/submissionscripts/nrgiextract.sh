#!/bin/bash
#SBATCH --job-name=nrblast
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 20
#SBATCH --partition=himem4
#SBATCH --mail-type=END
#SBATCH --mem=250G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o nrblast_%j.out
#SBATCH -e nrblast_%j.err



module load blast/2.7.1
for f in `cat con503.gi.list`; do blastdbcmd -entry $f -db /isg/shared/databases/blast/nr >> con503.tsbh; done
for f in `cat node503.gi.list`; do blastdbcmd -entry $f -db /isg/shared/databases/blast/nr >> node503.tsbh; done
