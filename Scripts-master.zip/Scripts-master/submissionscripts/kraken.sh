#!/bin/bash
#SBATCH --job-name=kraken
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 24
#SBATCH --partition=himem4
#SBATCH --mail-type=END
#SBATCH --mem=250G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o kraken_%j.out
#SBATCH -e kraken_%j.err



module load kraken/1.0
kraken -d /isg/shared/databases/kraken/standard contigs.fasta --threads 24
