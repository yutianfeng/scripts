#!/bin/bash
#SBATCH --job-name=metabat
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 24
#SBATCH --partition=himem4
#SBATCH --mail-type=END
#SBATCH --mem=250G
#SBATCH --mail-user=yutian.feng@uconn.edu
#SBATCH -o metabat_%j.out
#SBATCH -e metabat_%j.err

module load metabat/2.12.1
metabat -i contigs.fasta.gz -o binout